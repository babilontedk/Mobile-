import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <div className="max-w-3xl rounded-3xl border border-slate-800 bg-slate-900/70 p-10 text-center shadow-2xl">
        <h1 className="text-5xl font-semibold">Cloud Android Lab</h1>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-400">
          Launch a country-specific virtual Android phone, browse the web, install APKs, and control the device directly from your browser.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link href="/login" className="rounded-xl bg-cyan-500 px-5 py-3 font-medium text-slate-950">Login</Link>
          <Link href="/signup" className="rounded-xl border border-slate-700 px-5 py-3">Create account</Link>
        </div>
      </div>
    </main>
  );
}
