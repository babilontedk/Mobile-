import './globals.css';
import type { ReactNode } from 'react';

export const metadata = {
  title: 'Cloud Android Lab',
  description: 'Virtual Android phones in the cloud',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100">{children}</body>
    </html>
  );
}
