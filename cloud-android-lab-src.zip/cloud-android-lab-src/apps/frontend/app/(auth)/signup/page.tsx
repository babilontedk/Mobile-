import { AuthCard } from '../../../components/auth-card';

export default function SignupPage() {
  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <AuthCard mode="signup" />
    </main>
  );
}
