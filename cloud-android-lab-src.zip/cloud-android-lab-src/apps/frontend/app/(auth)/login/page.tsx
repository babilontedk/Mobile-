import { AuthCard } from '../../../components/auth-card';

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <AuthCard mode="login" />
    </main>
  );
}
