'use client';

import { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { getToken } from '../lib/api';

type Country = { code: string; name: string };
type Session = {
  id: string;
  countryCode: string;
  countryName: string;
  streamUrl: string;
  publicIp: string;
  timezone: string;
  localTime: string;
  androidVersion: string;
  deviceModel: string;
  status: string;
};

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000/api';

export function DashboardClient() {
  const token = useMemo(() => getToken(), []);
  const [countries, setCountries] = useState<Country[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [selectedCountry, setSelectedCountry] = useState('DE');
  const [activeSession, setActiveSession] = useState<Session | null>(null);
  const [status, setStatus] = useState('Ready');
  const [inputText, setInputText] = useState('');
  const [screenshot, setScreenshot] = useState('');

  useEffect(() => {
    if (!token) {
      window.location.href = '/login';
      return;
    }
    bootstrap();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function bootstrap() {
    const [countryRes, sessionsRes] = await Promise.all([
      fetch(`${API_BASE}/countries`).then((r) => r.json()),
      fetch(`${API_BASE}/sessions`, { headers: { Authorization: `Bearer ${token}` } }).then((r) => r.json()),
    ]);
    setCountries(countryRes);
    setSessions(sessionsRes);
    if (sessionsRes[0]) setActiveSession(sessionsRes[0]);
  }

  async function createSession() {
    setStatus('Starting emulator session...');
    const res = await fetch(`${API_BASE}/sessions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ countryCode: selectedCountry }),
    });
    const data = await res.json();
    setSessions((prev) => [data, ...prev.filter((s) => s.id !== data.id)]);
    setActiveSession(data);
    setStatus('Session created');
  }

  async function control(action: string) {
    if (!activeSession) return;
    setStatus(`Sending ${action}...`);
    await fetch(`${API_BASE}/sessions/${activeSession.id}/control`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, text: inputText }),
    });
    setStatus(`Action executed: ${action}`);
  }

  async function refreshSession() {
    if (!activeSession) return;
    const res = await fetch(`${API_BASE}/sessions/${activeSession.id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    setActiveSession(data);
    setSessions((prev) => prev.map((s) => (s.id === data.id ? data : s)));
    setStatus('Session refreshed');
  }

  async function resetSession() {
    if (!activeSession) return;
    setStatus('Resetting emulator...');
    const res = await fetch(`${API_BASE}/sessions/${activeSession.id}/reset`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    setActiveSession(data);
    setStatus('Reset complete');
  }

  async function takeScreenshot() {
    if (!activeSession) return;
    const res = await fetch(`${API_BASE}/sessions/${activeSession.id}/screenshot`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    setScreenshot(data.imageDataUrl);
    setStatus('Screenshot captured');
  }

  async function uploadApk(event: ChangeEvent<HTMLInputElement>) {
    if (!activeSession || !event.target.files?.[0]) return;
    setStatus('Uploading APK...');
    const form = new FormData();
    form.append('file', event.target.files[0]);
    await fetch(`${API_BASE}/sessions/${activeSession.id}/install-apk`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: form,
    });
    setStatus('APK installed');
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="mx-auto grid max-w-7xl gap-6 p-4 lg:grid-cols-[340px_1fr] lg:p-8">
        <aside className="space-y-6 rounded-3xl border border-slate-800 bg-slate-900/70 p-5">
          <div>
            <h1 className="text-2xl font-semibold">Cloud Android Lab</h1>
            <p className="mt-2 text-sm text-slate-400">Pick a country and spin up a browser-controlled Android session.</p>
          </div>

          <div className="space-y-3">
            <label className="text-sm text-slate-300">Country</label>
            <select value={selectedCountry} onChange={(e) => setSelectedCountry(e.target.value)} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3">
              {countries.map((country) => (
                <option key={country.code} value={country.code}>{country.name}</option>
              ))}
            </select>
            <button onClick={createSession} className="w-full rounded-xl bg-cyan-500 px-4 py-3 font-medium text-slate-950">Start virtual device</button>
          </div>

          <div>
            <h2 className="mb-2 text-sm font-semibold uppercase tracking-wide text-slate-400">Your sessions</h2>
            <div className="space-y-2">
              {sessions.map((session) => (
                <button key={session.id} onClick={() => setActiveSession(session)} className={`w-full rounded-2xl border p-3 text-left ${activeSession?.id === session.id ? 'border-cyan-500 bg-cyan-500/10' : 'border-slate-800 bg-slate-950'}`}>
                  <div className="font-medium">{session.countryName}</div>
                  <div className="text-xs text-slate-400">{session.status}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl bg-slate-950 p-4 text-sm text-slate-300">
            <div className="font-medium text-slate-100">Status</div>
            <p className="mt-2 text-slate-400">{status}</p>
          </div>
        </aside>

        <main className="space-y-6">
          <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
            <section className="rounded-3xl border border-slate-800 bg-slate-900/70 p-4">
              <div className="mx-auto max-w-sm rounded-[2.5rem] border-8 border-slate-800 bg-black shadow-2xl">
                <div className="h-[72vh] min-h-[520px] overflow-hidden rounded-[2rem] bg-slate-950">
                  {activeSession?.streamUrl ? (
                    <iframe title="Virtual Android device" src={activeSession.streamUrl} className="h-full w-full" />
                  ) : (
                    <div className="flex h-full items-center justify-center text-center text-slate-500">
                      Start a session to open a virtual phone.
                    </div>
                  )}
                </div>
              </div>
            </section>

            <section className="space-y-6 rounded-3xl border border-slate-800 bg-slate-900/70 p-5">
              <div>
                <h2 className="text-xl font-semibold">Device info</h2>
                <div className="mt-4 space-y-2 text-sm text-slate-300">
                  <Info label="IP address" value={activeSession?.publicIp} />
                  <Info label="Country" value={activeSession?.countryName} />
                  <Info label="Timezone" value={activeSession?.timezone} />
                  <Info label="Local time" value={activeSession?.localTime} />
                  <Info label="Android version" value={activeSession?.androidVersion} />
                  <Info label="Device model" value={activeSession?.deviceModel} />
                </div>
              </div>

              <div>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Controls</h3>
                <div className="grid grid-cols-3 gap-2">
                  <ControlButton onClick={() => control('home')} label="Home" />
                  <ControlButton onClick={() => control('back')} label="Back" />
                  <ControlButton onClick={() => control('recent')} label="Recent" />
                  <ControlButton onClick={() => control('rotate')} label="Rotate" />
                  <ControlButton onClick={takeScreenshot} label="Screenshot" />
                  <ControlButton onClick={refreshSession} label="Refresh" />
                </div>
                <button onClick={resetSession} className="mt-3 w-full rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-amber-300">Reset emulator</button>
              </div>

              <div>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Text input</h3>
                <input value={inputText} onChange={(e) => setInputText(e.target.value)} className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3" placeholder="Send text via ADB input" />
                <button onClick={() => control('text')} className="mt-3 w-full rounded-xl bg-slate-100 px-4 py-3 text-slate-950">Send text</button>
              </div>

              <div>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Install APK</h3>
                <label className="block w-full cursor-pointer rounded-xl border border-dashed border-slate-700 px-4 py-6 text-center text-sm text-slate-400">
                  Upload APK
                  <input type="file" accept=".apk" className="hidden" onChange={uploadApk} />
                </label>
              </div>
            </section>
          </div>

          {screenshot && (
            <section className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-semibold">Latest screenshot</h2>
                <a href={screenshot} download="android-screenshot.png" className="rounded-xl bg-cyan-500 px-4 py-2 text-sm font-medium text-slate-950">Download</a>
              </div>
              <img src={screenshot} alt="Screenshot" className="max-h-[420px] rounded-2xl border border-slate-800" />
            </section>
          )}
        </main>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-xl border border-slate-800 bg-slate-950 px-4 py-3">
      <span className="text-slate-400">{label}</span>
      <span className="text-right text-slate-100">{value || '—'}</span>
    </div>
  );
}

function ControlButton({ onClick, label }: { onClick: () => void; label: string }) {
  return <button onClick={onClick} className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-3 text-sm">{label}</button>;
}
