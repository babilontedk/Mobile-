'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FormEvent, useState } from 'react';
import { api, setToken } from '../lib/api';

export function AuthCard({ mode }: { mode: 'login' | 'signup' }) {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const path = mode === 'login' ? '/auth/login' : '/auth/signup';
      const payload = mode === 'login' ? { email, password } : { name, email, password };
      const result = await api<{ accessToken: string }>(path, { method: 'POST', body: JSON.stringify(payload) });
      setToken(result.accessToken);
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900/70 p-8 shadow-2xl">
      <h1 className="text-3xl font-semibold">{mode === 'login' ? 'Welcome back' : 'Create account'}</h1>
      <p className="mt-2 text-sm text-slate-400">Launch a cloud Android phone from your browser.</p>
      <form className="mt-6 space-y-4" onSubmit={onSubmit}>
        {mode === 'signup' && (
          <input className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
        )}
        <input className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3" placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <p className="rounded-xl bg-rose-500/10 p-3 text-sm text-rose-300">{error}</p>}
        <button className="w-full rounded-xl bg-cyan-500 px-4 py-3 font-medium text-slate-950 disabled:opacity-50" disabled={loading}>
          {loading ? 'Please wait...' : mode === 'login' ? 'Login' : 'Sign up'}
        </button>
      </form>
      <p className="mt-6 text-sm text-slate-400">
        {mode === 'login' ? 'Need an account?' : 'Already registered?'}{' '}
        <Link className="text-cyan-400" href={mode === 'login' ? '/signup' : '/login'}>
          {mode === 'login' ? 'Sign up' : 'Login'}
        </Link>
      </p>
    </div>
  );
}
